#!/usr/bin/env python3
"""
WiltonVerse - parse_chatgpt_export.py
--------------------------------------
Processes the conversations.json from a ChatGPT data export.
Extracts WiltonVerse-related conversations and produces:
  - A readable markdown summary of all relevant conversations
  - A structured JSON of extracted modules/concepts found
  - A draft YAML patch for module_registry.yaml based on findings
  - A SHA-256 hash of the output for evidence chain

Usage:
    python parse_chatgpt_export.py --input conversations.json --output ../07_export/

Requirements:
    pip install pyyaml
"""

import json
import os
import sys
import hashlib
import argparse
import re
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except ImportError:
    print("[ERROR] PyYAML not installed. Run: pip install pyyaml")
    sys.exit(1)

# ─── Keywords that signal WiltonVerse content ─────────────────────────────────
WV_KEYWORDS = [
    "wiltonverse", "wilton verse", "wv_", "rcmas", "mag-pd", "nucleus enterprise",
    "truth_policy", "truth policy", "verified", "declared", "unknown",
    "fail_closed", "fail-closed", "add_only", "add-only",
    "anti-illusion", "anti_illusion", "constitutional layer",
    "governance", "governança", "epistemic", "epistemológico",
    "provenance", "provenância", "sha-256", "rfc3161",
    "meta-agente", "meta-agent", "kernel governado",
    "module_registry", "canonical_manifest", "benchmark_harness",
    "pró-labore", "pro-labore", "mei", "nf-e", "das boleto",
    "heartbeat", "runtime fabric", "compilation layer",
    "bayesian", "lyapunov", "coherence index",
    "wilton", "wv-",
]

# ─── Module concept patterns to extract from text ─────────────────────────────
MODULE_PATTERNS = [
    r'\bWV[-_][A-Z0-9\-_]+\b',
    r'\bRCMAS[-_][A-Z0-9\-_]*\b',
    r'\bMAG[-_]PD\b',
    r'\bNUCLEUS\b',
]


def sha256_of_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def is_wv_relevant(text: str) -> bool:
    text_lower = text.lower()
    return any(kw.lower() in text_lower for kw in WV_KEYWORDS)


def extract_module_ids(text: str) -> list:
    found = set()
    for pattern in MODULE_PATTERNS:
        matches = re.findall(pattern, text, re.IGNORECASE)
        found.update(m.upper() for m in matches)
    return sorted(found)


def extract_messages(conversation: dict) -> list:
    """Extract clean messages from a conversation object."""
    messages = []
    mapping = conversation.get("mapping", {})
    
    # Build message chain
    def get_text(node):
        msg = node.get("message")
        if not msg:
            return None
        content = msg.get("content", {})
        if isinstance(content, dict):
            parts = content.get("parts", [])
            text = " ".join(str(p) for p in parts if isinstance(p, str))
        elif isinstance(content, str):
            text = content
        else:
            text = ""
        if not text.strip():
            return None
        role = msg.get("author", {}).get("role", "unknown")
        ts = msg.get("create_time")
        return {"role": role, "text": text.strip(), "ts": ts}

    for node_id, node in mapping.items():
        extracted = get_text(node)
        if extracted:
            messages.append(extracted)

    messages.sort(key=lambda m: m.get("ts") or 0)
    return messages


def process_export(input_path: str, output_dir: str):
    print(f"\n{'='*60}")
    print("  WiltonVerse - ChatGPT Export Parser")
    print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")

    input_path = Path(input_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if not input_path.exists():
        print(f"[ERROR] File not found: {input_path}")
        sys.exit(1)

    print(f"[1/5] Loading {input_path.name} ...")
    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if not isinstance(data, list):
        print("[ERROR] Expected a list of conversations. Check your export file.")
        sys.exit(1)

    total = len(data)
    print(f"       Found {total} total conversations.")

    # ─── Filter relevant conversations ───────────────────────────────────────
    print(f"[2/5] Scanning for WiltonVerse content ...")
    relevant = []
    all_module_ids = set()

    for conv in data:
        title = conv.get("title", "Untitled")
        messages = extract_messages(conv)
        full_text = " ".join(m["text"] for m in messages)
        
        if is_wv_relevant(full_text) or is_wv_relevant(title):
            module_ids = extract_module_ids(full_text)
            all_module_ids.update(module_ids)
            relevant.append({
                "id": conv.get("id", "unknown"),
                "title": title,
                "create_time": conv.get("create_time"),
                "update_time": conv.get("update_time"),
                "message_count": len(messages),
                "module_ids_found": module_ids,
                "messages": messages,
                "text_hash": sha256_of_text(full_text),
            })

    print(f"       {len(relevant)} of {total} conversations are WiltonVerse-relevant.")
    print(f"       Module IDs found: {len(all_module_ids)}")

    if not relevant:
        print("\n[WARNING] No WiltonVerse-relevant conversations found.")
        print("  Check that you exported the correct account.")
        print("  Try placing conversations.json in the same folder and re-running.")
        sys.exit(0)

    # ─── Sort by date ─────────────────────────────────────────────────────────
    relevant.sort(key=lambda c: c.get("create_time") or 0)

    # ─── Write Markdown summary ───────────────────────────────────────────────
    print(f"[3/5] Writing markdown summary ...")
    md_path = output_dir / "chatgpt_wv_conversations.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# WiltonVerse — ChatGPT Export Summary\n\n")
        f.write(f"- Exported: {datetime.now(timezone.utc).isoformat()}\n")
        f.write(f"- Total conversations scanned: {total}\n")
        f.write(f"- WiltonVerse-relevant: {len(relevant)}\n")
        f.write(f"- Module IDs detected: {', '.join(sorted(all_module_ids)) or 'none'}\n\n")
        f.write("---\n\n")

        for i, conv in enumerate(relevant, 1):
            ts = conv.get("create_time")
            date_str = datetime.fromtimestamp(ts).strftime("%Y-%m-%d") if ts else "unknown date"
            f.write(f"## {i}. {conv['title']}\n\n")
            f.write(f"- Date: {date_str}\n")
            f.write(f"- Messages: {conv['message_count']}\n")
            f.write(f"- Modules found: {', '.join(conv['module_ids_found']) or 'none detected'}\n")
            f.write(f"- Hash: `{conv['text_hash'][:16]}...`\n\n")

            # Write first 3 user messages as preview
            user_msgs = [m for m in conv["messages"] if m["role"] == "user"][:3]
            if user_msgs:
                f.write("**Key user inputs (preview):**\n\n")
                for m in user_msgs:
                    preview = m["text"][:400].replace("\n", " ")
                    f.write(f"> {preview}{'...' if len(m['text']) > 400 else ''}\n\n")
            f.write("---\n\n")

    # ─── Write structured JSON ────────────────────────────────────────────────
    print(f"[4/5] Writing structured JSON ...")
    json_path = output_dir / "chatgpt_wv_structured.json"
    export_data = {
        "meta": {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "total_conversations_scanned": total,
            "wv_relevant_count": len(relevant),
            "all_module_ids_found": sorted(all_module_ids),
        },
        "conversations": [
            {
                "id": c["id"],
                "title": c["title"],
                "message_count": c["message_count"],
                "module_ids_found": c["module_ids_found"],
                "text_hash": c["text_hash"],
            }
            for c in relevant
        ]
    }
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(export_data, f, indent=2, ensure_ascii=False)

    # ─── Write registry patch ─────────────────────────────────────────────────
    print(f"[5/5] Writing module registry patch ...")
    patch_modules = []
    for mod_id in sorted(all_module_ids):
        patch_modules.append({
            "id": mod_id,
            "name": mod_id.replace("WV-", "").replace("-", " ").title(),
            "class": "FILL_IN",
            "purpose": "FILL_IN — extracted from ChatGPT history",
            "status": "REVIEW_NEEDED",
            "truth_state": "DECLARED",
            "owner": "Wiltonverse",
            "dependencies": [],
            "promotable": True,
            "runtime_capable": False,
            "notes": f"Auto-detected from ChatGPT export. Requires manual review.",
        })

    patch = {
        "registry_patch_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "truth_state": "DECLARED",
        "instruction": "Review each module below. Fill in 'class' and 'purpose'. Merge into module_registry.yaml.",
        "modules_detected": patch_modules,
    }
    patch_path = output_dir / "registry_patch_from_export.yaml"
    with open(patch_path, "w", encoding="utf-8") as f:
        yaml.dump(patch, f, allow_unicode=True, sort_keys=False, default_flow_style=False)

    # ─── Hash all outputs for evidence ───────────────────────────────────────
    evidence = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_file": str(input_path),
        "outputs": {}
    }
    for out_path in [md_path, json_path, patch_path]:
        with open(out_path, "rb") as f:
            evidence["outputs"][out_path.name] = hashlib.sha256(f.read()).hexdigest()

    evidence_path = output_dir / "export_parse_evidence.json"
    with open(evidence_path, "w", encoding="utf-8") as f:
        json.dump(evidence, f, indent=2)

    # ─── Final report ─────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print("  DONE")
    print(f"{'='*60}")
    print(f"  Relevant conversations : {len(relevant)}")
    print(f"  Module IDs detected    : {len(all_module_ids)}")
    print(f"\n  Output files:")
    print(f"    {md_path.name}          — readable summary")
    print(f"    {json_path.name}    — structured data")
    print(f"    {patch_path.name} — registry patch to review")
    print(f"    {evidence_path.name}      — hash evidence")
    print(f"\n  Next step:")
    print(f"    Open registry_patch_from_export.yaml")
    print(f"    Fill in 'class' and 'purpose' for each module")
    print(f"    Merge into 03_registry/module_registry.yaml")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Parse ChatGPT export and extract WiltonVerse content"
    )
    parser.add_argument(
        "--input",
        default="conversations.json",
        help="Path to conversations.json from ChatGPT export (default: conversations.json)"
    )
    parser.add_argument(
        "--output",
        default="../07_export/",
        help="Output directory (default: ../07_export/)"
    )
    args = parser.parse_args()
    process_export(args.input, args.output)
